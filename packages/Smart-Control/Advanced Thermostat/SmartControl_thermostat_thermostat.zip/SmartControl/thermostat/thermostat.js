[{
  Name: "Thermostat Widget",
  Author: "Gael Le Pennec",
  Version: "2017-11-26",

  GroupName: '',
  IconImage: 'pages/control/widgets/homegenie/generic/images/temperature.png',
  StatusText: '',
  Description: '',

  levelKnobBindValue: 'Heating',

  RenderView: function (cuid, module) {

    var container = $(cuid);
    var widget = container.find('[data-ui-field=widget]');
    var controlpopup = widget.data('ControlPopUp');
    var _this = this;
    var selectedheadedmode = '';

    if (!controlpopup) {
      
      container.find('[data-ui-field=controlpopup]').trigger('create');
      controlpopup = container.find('[data-ui-field=controlpopup]').popup();
      widget.data('ControlPopUp', controlpopup);

      widget.find('[data-ui-field=options]').on('click', function () {
        if ($(cuid).find('[data-ui-field=widget]').data('ControlPopUp')) {
          $(cuid).find('[data-ui-field=widget]').data('ControlPopUp').popup('open');
        }
      });

      controlpopup.find('[data-ui-field=level_knob]').knob({
        'release': function (v) {
          v = Math.round(v * 10) / 10;
          // API expects value to be always in Celsius scale
          if (HG.WebApp.Locales.GetTemperatureUnit() != 'Celsius')
            v = (v-32)/1.8;
          var setPoint = HG.WebApp.Utility.GetModulePropertyByName(module, 'Thermostat.SetPoint.' + _this.selectedheadedmode);
          if (setPoint != null) setPoint.Value = v;
          HG.Control.Modules.ServiceCall('Thermostat.SetPointSet/' + _this.selectedheadedmode, module.Domain, module.Address, v, function (data) { });
        },
        'change': function (v) {
          //controlpopup.find('[data-ui-field=status]').html(controlpopup.find('[data-ui-field=level_knob]').val() + '&deg;');
        }
      });

      if (HG.WebApp.Locales.GetTemperatureUnit() == 'Celsius') {
        controlpopup.find('[data-ui-field=level_knob]').trigger('configure', {
          min: 5,
          max: 35,
          step: 0.5
        });
      } else {
        controlpopup.find('[data-ui-field=level_knob]').trigger('configure', {
          min: 40,
          max: 100,
          step: 1
        });
      }

      // settings button
      widget.find('[data-ui-field=settings]').on('click', function () {
        if (module.Domain == 'HomeAutomation.HomeGenie.Automation') {
          HG.WebApp.ProgramEdit._CurrentProgram.Domain = module.Domain;
          HG.WebApp.ProgramEdit._CurrentProgram.Address = module.Address;
          HG.WebApp.ProgramsList.UpdateOptionsPopup();
        }
        else {
          HG.WebApp.Control.EditModule(module);
        }
      });

      // popup values on open
      controlpopup.on('popupbeforeposition', function (evt, ui) {
        _this.selectedheadedmode = '';
        if (_this.levelKnobBindValue == 'Heating')
        {
          _this.EditHeatSetPoint(controlpopup, module,_this);
        } 
      });
      // set point buttons events
        controlpopup.find('[data-ui-field=heat_setpoint_absence]').on('click', function () {
        controlpopup.find('[data-ui-field=heat_setpoint_absence]').addClass('ui-btn-active');
        controlpopup.find('[data-ui-field=heat_setpoint_presence]').removeClass('ui-btn-active');
        _this.selectedheadedmode = 'Absence';
        _this.EditHeatSetPoint(controlpopup, module,_this);
      });
      // set point buttons events
        controlpopup.find('[data-ui-field=heat_setpoint_presence]').on('click', function () {
        controlpopup.find('[data-ui-field=heat_setpoint_absence]').removeClass('ui-btn-active');
        controlpopup.find('[data-ui-field=heat_setpoint_presence]').addClass('ui-btn-active');
        _this.selectedheadedmode = 'Presence';
        _this.EditHeatSetPoint(controlpopup, module,_this);
      });
      // thermostat mode buttons events
      widget.find('[data-ui-field=mode_off]').on('click', function () {
        widget.find('[data-ui-field=mode_off]').addClass('ui-btn-active');
        widget.find('[data-ui-field=mode_absence]').removeClass('ui-btn-active');
        widget.find('[data-ui-field=mode_presence]').removeClass('ui-btn-active');
        HG.Control.Modules.ServiceCall("Thermostat.ModeSet", module.Domain, module.Address, "Off", function (data) { });
      });
      widget.find('[data-ui-field=mode_absence]').on('click', function () {
        widget.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
        widget.find('[data-ui-field=mode_absence]').addClass('ui-btn-active');
        widget.find('[data-ui-field=mode_presence]').removeClass('ui-btn-active');
        HG.Control.Modules.ServiceCall("Thermostat.ModeSet", module.Domain, module.Address, "Absence", function (data) { });
      });
      widget.find('[data-ui-field=mode_presence]').on('click', function () {
        widget.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
        widget.find('[data-ui-field=mode_absence]').removeClass('ui-btn-active');
        widget.find('[data-ui-field=mode_presence]').addClass('ui-btn-active');
        HG.Control.Modules.ServiceCall("Thermostat.ModeSet", module.Domain, module.Address, "Presence", function (data) { });
      });
    }

    this.Description = (module.Domain.substring(module.Domain.lastIndexOf('.') + 1)) + ' ' + module.Address;

    widget.find('[data-ui-field=name]').html(module.Name);
    widget.find('[data-ui-field=description]').html(this.Description);
    controlpopup.find('[data-ui-field=group]').html(this.GroupName);
    controlpopup.find('[data-ui-field=name]').html(module.Name);

    var imagesrc = 'pages/control/widgets/homegenie/generic/images/temperature.png';
    // display Temperature
    var temperatureField = HG.WebApp.Utility.GetModulePropertyByName(module, "Sensor.Temperature");
    var temperature = 0;
    if (temperatureField != null) {
      temperature = temperatureField.Value.replace(',', '.');
      widget.find('[data-ui-field=temperature_value]').html(HG.WebApp.Utility.FormatTemperature(temperature));
    } else {
      widget.find('[data-ui-field=temperature_value]').html('');
    }

      
    // display current Heating SetPoint
    var operatingMode = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.Mode");
    var _extmode = '';
    if (operatingMode != null) {
      _extmode = operatingMode.Value;
    }
    var heatTo = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.SetPoint." + _extmode);
    if (heatTo == null || heatTo.Value == '') {
      widget.find('[data-ui-field=heat_field]').hide();
      widget.find('[data-ui-field=mode_heat]').hide();
    //  controlpopup.find('[data-ui-field=heat_setpoint_absence]').show();
    //  controlpopup.find('[data-ui-field=heat_setpoint_presence]').show();
    } else {
      widget.find('[data-ui-field=heat_field]').show();
      widget.find('[data-ui-field=mode_heat]').show();
     // controlpopup.find('[data-ui-field=heat_setpoint_absence]').show();
     // controlpopup.find('[data-ui-field=heat_setpoint_presence]').show();
      var temperature = Math.round(heatTo.Value.replace(',', '.') * 100) / 100;
      widget.find('[data-ui-field=heatset_value]').html(HG.WebApp.Utility.FormatTemperature(temperature));
    }

    // display/hide SetPoints in the status bar depending on mode
    var operatingMode = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.Mode");
    var displayMode = '---';
    if (operatingMode != null) {
      displayMode = operatingMode.Value;
      switch (displayMode) {
        case 'Off':
          widget.find('[data-ui-field=heat_field]').css('opacity', '0');
           break;
        case 'Absence':
          widget.find('[data-ui-field=heat_field]').css('opacity', '0.5');
          break;
        case 'Presence':
          widget.find('[data-ui-field=heat_field]').css('opacity', '1');
          break;
        default:
           widget.find('[data-ui-field=heat_field]').css('opacity', '0.5');
          break;
      }
    }
    widget.find('[data-ui-field=mode_value]').html(displayMode);


    // reset mode buttons' state
    widget.find('[data-ui-field=mode_off]').addClass('ui-btn-active');
    widget.find('[data-ui-field=mode_absence]').removeClass('ui-btn-active');
    widget.find('[data-ui-field=mode_presence]').removeClass('ui-btn-active');
    // set current mode buttons' state from module properties 'Thermostat.Mode'
    var thermostatMode = HG.WebApp.Utility.GetModulePropertyByName(module, 'Thermostat.Mode');
    if (thermostatMode != null) {
      displayMode = thermostatMode.Value;
      switch (displayMode) {
        case 'Off':
          widget.find('[data-ui-field=mode_off]').addClass('ui-btn-active');
          widget.find('[data-ui-field=mode_absence]').removeClass('ui-btn-active');
          widget.find('[data-ui-field=mode_presence]').removeClass('ui-btn-active');
           break;
        case 'Absence':
          widget.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
          widget.find('[data-ui-field=mode_absence]').addClass('ui-btn-active');
          widget.find('[data-ui-field=mode_presence]').removeClass('ui-btn-active');
          _this.EditHeatSetPoint(controlpopup, module,_this);
          break;
        case 'Presence':
          widget.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
          widget.find('[data-ui-field=mode_absence]').removeClass('ui-btn-active');
          widget.find('[data-ui-field=mode_presence]').addClass('ui-btn-active');
          _this.EditHeatSetPoint(controlpopup, module,_this);
          break;
      }
    }

    // display status line (operating state + mode)
    var displayState = '';
    var operatingState = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.OperatingState");
    if (operatingState != null) {
      if (operatingState.Value == 'Heating')
        widget.find('[data-ui-field=heatset_image]').css('color', 'red');
      else
        widget.find('[data-ui-field=heatset_image]').css('color', '');
      displayState = operatingState.Value;
    }
    widget.find('[data-ui-field=operating_value]').html(displayState);

  },

  EditHeatSetPoint: function (controlpopup, module,_this) {
    var levelKnob = controlpopup.find('[data-ui-field=level_knob]');
    if(_this.selectedheadedmode == null || _this.selectedheadedmode == ''){
      var operatingMode = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.Mode");
      if (operatingMode != null) {
        displayMode = operatingMode.Value;
        switch (displayMode) {
          case 'Absence':
            //Faire une selection en fonction du mode courant
             _this.selectedheadedmode = 'Absence';
            controlpopup.find('[data-ui-field=heat_setpoint_absence]').addClass('ui-btn-active');
            controlpopup.find('[data-ui-field=heat_setpoint_presence]').removeClass('ui-btn-active');
            break;
          case 'Presence':
            //Faire une selection en fonction du mode courant
            _this.selectedheadedmode = 'Presence';
            controlpopup.find('[data-ui-field=heat_setpoint_absence]').removeClass('ui-btn-active');
            controlpopup.find('[data-ui-field=heat_setpoint_presence]').addClass('ui-btn-active');
            break;
          case 'Off':
            //Faire une selection en fonction du mode courant
            _this.selectedheadedmode = 'Presence';
            controlpopup.find('[data-ui-field=heat_setpoint_absence]').removeClass('ui-btn-active');
            controlpopup.find('[data-ui-field=heat_setpoint_presence]').addClass('ui-btn-active');
            break;
        }
      }
   
    }
    // show current heat setpoint
    var heatSetPoint = HG.WebApp.Utility.GetModulePropertyByName(module, 'Thermostat.SetPoint.'+_this.selectedheadedmode);
    if (heatSetPoint != null) {
      levelKnob.val(HG.WebApp.Utility.GetLocaleTemperature(heatSetPoint.Value)).trigger('change');
      //controlpopup.find('[data-ui-field=status]').html(heatSetPoint.Value + '&deg;');
    }
    this.levelKnobBindValue = 'Heating';
  }

}]