$$.widget = {
  name: 'ServicePersonaWidget',
  version: '1.0',
  author: 'M.Tudury',
  release: '2017-10-30',
  icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAuCAYAAAAsnen7AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4QsLFSoiEfs4wAAAAB1pVFh0Q29tbWVudAAAAAAAQ3JlYXRlZCB3aXRoIEdJTVBkLmUHAAACdUlEQVRIx+3WsWsaYRzG8ec9ChcMpli6KIiDcBwqAaFJ8DjQJYu743E4ZBfiEAgdQskQcPA/EHGrUwaFbLrckoKQoYjkeHkjWCiKQ0Bw8e2UQtL37t4LSEnpra/34cfL931PUigUsI1HwZae//D24XcyP1JVFYZh8FQqBQBgjMFxHLJer18/sW3bvHfT4+aJibk5x9ycwzwx0bvpcdu2udd7xK/j8y/nXEkrqI1rmDxOnq1pUQ1NvYmNu8Hl50siPbFt21xJKyjflv9AAWDyOEH5tgwlrUA0ueK1p1bVQm1cC9z/2rgGq2pBVdVg2DAMPpwNhZOKJh/OhjAMgwfCqVQKo9VIOq3RaoSnYv7OAWGMIR/JSyP5SB6MsWDYcRxSTBShRbVAVItqKCaKcByHBMLr9RqdVgdNvRkIN/UmOq0OXp5Czz1ut9tk427QP+gLJ9eiGvoHfWzcDdrtNgl18p4OilW1MJwNf5eSj+RRTBTRaXWEqBT82kuIvLlvnvA+rtfrfLlchoJisRgajQbxhCuVCk+Wkrj7cRcK3o/vo8IqvNvtEiFMKcXh6hAX3y9Cwcfvj0Ep9d5jSumVHtND76ke00EpvfKEF4vFGeEE8Z24NBrfiYNwgsViceZbhfvgIrOXkYYzexm4D67E7eay0DBzJW636f0U2UhWGs5GspjeT4NhSilyuzlpOLebe1aEHxyqjJdFeMJhyhAV4XtXyJYhKsIXli1DVIQvLFuGqAhfWLYMURFBsFQZoiJ8YZkyvIoI/IIEleFVROA/euYynH46hfnRFK4ffTgC+8bCw9dfr1H6WUISSeH6DDMMBoN/5Cv99uBfvE8d+BojvEMAAAAASUVORK5CYII='
};

$$.summary_general_template = '<g fill="{{personaColor}}" stroke="#ffffff" style="stroke-width: 2;"><circle cx="30" cy="20" r="18"></circle><text x="28" y="26" style="font-size: 16px;">{{PersonaCount}}</text></g>';

$$.summary_item_template = '<g fill="{{personaColor}}" stroke="#ffffff" style="stroke-width: 1;" transform="matrix({{personaSizeFactor}},0,0,{{personaSizeFactor}},{{personaPositionX}},{{personaPositionY}})"><circle cx="12" cy="10" r="6"></circle><path d="M 5 20 l 3 18 h 8 l 3 -18 Z"></path></g>';

$$.summary_template = '<div class="ui-block-a">\
        <svg height="80px">\
		{{summaryItems}}\
        </svg>\
    </div>';

$$.persona_item_template = '<svg height="50px"><g fill="{{personaColor}}" stroke="#ffffff" style="stroke-width: 1;" transform="matrix(1,0,0,1,40,0)"><circle cx="12" cy="10" r="6"></circle><path d="M 5 20 l 3 18 h 8 l 3 -18 Z"></path></g></svg>';

$$.persona_template = '<div class="ui-block-a" data-ui-field="persona{{personaNum}}svg">\
		{{persona_item_svg}}\
    </div>\
    <div class="ui-block-b">\
        <div>{{personaName}}</div>\
        <div data-role="controlgroup" data-type="horizontal">\
          <a data-ui-field="persona{{personaNum}}btn-off" data-locale-id="control_module_off" class="ui-btn" href="#" data-val="{{personaName}}">Off</a>\
          <a data-ui-field="persona{{personaNum}}btn-on" data-locale-id="control_module_on" class="ui-btn" href="#" data-val="{{personaName}}">On</a>\
        </div>\
    </div>';

/*
# Quick-Reference

 "$$" is the widget class instance object

 Widget class methods and properties:

 Get the jQuery element for a "data-ui" field
   $$.field('<widget_field_name>')

 Get the jQuery element in the main document
   $$.field('<document_tree_selector>', true)

 Call HG API Web Service 
   $$.apiCall('<api_method>', function(response){ ... })

 Get the bound module object
   $$.module

 Get a parameter of the bound module
   $$.module.prop('<param_name>')
   e.g.: $$.module.prop('Status.Level')

 Invoke a module command
   $$.module.command('<api_command>', '<command_options>', function(response) { ... })
   e.g.: $$.module.command('Control.Off')

 Shorthand for HG.Ui
   $$.ui

 Shorthand for HG.WebApp.Utility
   $$.util

 Shorthand for HG.WebApp.Locales
   $$.locales

 Blink a widget field and the status led image (if present)
   $$.signalActity('<widget_field_name>') 

 For a reference of HomeGenie Javascript API see:
   https://github.com/genielabs/HomeGenie/tree/master/BaseFiles/Common/html/js/api

*/

// Widget base class methods

// This method is called when the widget starts
$$.onStart = function() {
  $$.field('icon').attr('src', $$.widget.IconImage);
  if ($$.module.prop('Personas')) {
  	$$.RenderTemplates(JSON.parse($$.module.prop('Personas').Value));
    $$.RenderSummary(JSON.parse($$.module.prop('Personas').Value));
  
    // handle ui elements events
    /*
    $$.field('content_summary').bind('click', function(){
      $$.field('content').toggle();
    });*/

  }
    
  $$.field('settings').on('click', function () {
    //$$.ui.EditModule($$.module);
    $$.field('personapopup').popup('open', {transition: 'pop', positionTo: 'window', icon: $$.widget.icon});
  });
  $$.field('personapopup').popup();
}

// This method is called when the widget UI is request to refresh its view
$$.onRefresh = function () {
  $$.field('lbl-name').html($$.module.Name + " (" + $$.module.DeviceType + ")");
  $$.field('lbl-description').html('Hello World');
  $$.field('lbl-info').html('default widget template');
  
}

// This method is called when the bound module raises a parameter event
// eg.: parameter = 'Status.Level', value = '1'
$$.onUpdate = function(parameter, value) {
  if ($$.module.prop('Personas')) {
    $$.RenderTemplates(JSON.parse($$.module.prop('Personas').Value));
    $$.RenderSummary(JSON.parse($$.module.prop('Personas').Value));
  }
}

// This method is called when the widget stops
$$.onStop = function() {
}


// user-defined methods implemented for this widget

btnOffClicked = function (persona_name) {
  HG.Control.Modules.ServiceCall("UpdatePersona", "Service.Persona", persona_name, "0", function (data) { });
}

btnOnClicked = function (persona_name) {
  HG.Control.Modules.ServiceCall("UpdatePersona", "Service.Persona", persona_name, "1", function (data) { });
}

$$.getStatusOfPersona = function (persona_name) {
  var prop = $$.module.prop('personna.'+persona_name);
  if (prop)
  	return prop.Value;
  return null;
}

$$.getColorOfPersona = function (persona_name) {
  var personacolor = '#000000';
  if ($$.getStatusOfPersona(persona_name) == "1")
    personacolor = '#00aa00';
  return personacolor;
}

$$.RenderTemplates = function (personas) {
  if ($$.field('content').html() == '') {
    var torender = "";
    for (var i = 0; i < personas.length; i++) {
      var persona = personas[i];
      var personacolor = $$.getColorOfPersona(persona.Name);
      var personaitem = $$.persona_item_template.replace(/{{personaName}}/g, persona.Name).replace(/{{personaNum}}/g, i).replace(/{{personaColor}}/g, personacolor);
      torender += $$.persona_template.replace(/{{persona_item_svg}}/g, personaitem).replace(/{{personaName}}/g, persona.Name).replace(/{{personaNum}}/g, i).replace(/{{personaColor}}/g, personacolor);
    }
    $$.field('content').html(torender);

    for (var i = 0; i < personas.length; i++) {
      var persona = personas[i];
      $$.field('persona'+i+'btn-off').bind('click', function(){
        btnOffClicked($(this).attr('data-val'));
      });
      $$.field('persona'+i+'btn-on').bind('click', function(){
        btnOnClicked($(this).attr('data-val'));
      });
    }
  } else {
    for (var i = 0; i < personas.length; i++) {
      var persona = personas[i];
      var personacolor = $$.getColorOfPersona(persona.Name);
      var personaitem = $$.persona_item_template.replace(/{{personaName}}/g, persona.Name).replace(/{{personaNum}}/g, i).replace(/{{personaColor}}/g, personacolor);
      $(document.querySelectorAll('div[data-ui-field="persona'+i+'svg"]')).html(personaitem);
    }
  }
}

$$.RenderSummary = function (personas) {
  var torender = $$.summary_general_template.replace(/{{PersonaCount}}/g, $$.module.prop('Sensor.NbAtHome').Value).replace(/{{personaColor}}/g, $$.module.prop('Sensor.AtHome').Value == "1" ? "#00aa00" : "#000000");
  var lastxpos = 50;
  for (var i = 0; i < personas.length; i++) {
    var persona = personas[i];
	var personacolor = $$.getColorOfPersona(persona.Name);
    var sfact = 1;
    if (persona.DisplaySizeFactor)
      sfact = persona.DisplaySizeFactor;    
    var posx = sfact * 20;
    torender += $$.summary_item_template.replace(/{{personaPositionY}}/g, 35-(sfact*35)).replace(/{{personaSizeFactor}}/g, sfact).replace(/{{personaPositionX}}/g, lastxpos).replace(/{{personaNum}}/g, i).replace(/{{personaColor}}/g, personacolor);
    lastxpos += posx;
  }
  torender = $$.summary_template.replace(/{{summaryItems}}/, torender);
  $$.field('content_summary').html(torender);
}
