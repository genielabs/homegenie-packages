﻿[{
    Name: "Ademco Alarm Panel",
    Author: "Dan Santee",
    Version: "2/15/2015",

    GroupName: '',
    IconImage: 'pages/control/widgets/AlarmPanel/Ademco/Panel/Panel.png',
    StatusText: '',
    Description: '',
    UpdateTime: '',

    RenderView: function (cuid, module) {
        var container = $(cuid);
        var widget = container.find('[data-ui-field=widget]');
        //
        if (!this.Initialized) {
            this.Initialized = true;
            // Keypad buttons
            widget.find('[data-ui-field=k1]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "1", function (data) { });
            });
            widget.find('[data-ui-field=k2]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "2", function (data) { });
            });
            widget.find('[data-ui-field=k3]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "3", function (data) { });
            });
            widget.find('[data-ui-field=k4]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "4", function (data) { });
            });
            widget.find('[data-ui-field=k5]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "5", function (data) { });
            });
            widget.find('[data-ui-field=k6]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "6", function (data) { });
            });
            widget.find('[data-ui-field=k7]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "7", function (data) { });
            });
            widget.find('[data-ui-field=k8]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "8", function (data) { });
            });
            widget.find('[data-ui-field=k9]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "9", function (data) { });
            });
            widget.find('[data-ui-field=k0]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "0", function (data) { });
            });
            widget.find('[data-ui-field=kStar]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "*", function (data) { });
            });
            widget.find('[data-ui-field=kPound]').on('click', function () {
                HG.Control.Modules.ServiceCall("Keypad", module.Domain, module.Address, "#", function (data) { });
            });

            // Quick-access buttons
            widget.find('[data-ui-field=bDisarm]').on('click', function () {
                HG.Control.Modules.ServiceCall("QuickAccess", module.Domain, module.Address, "Disarm", function (data) { });
            });
            widget.find('[data-ui-field=bAway]').on('click', function () {
                HG.Control.Modules.ServiceCall("QuickAccess", module.Domain, module.Address, "Away", function (data) { });
            });
            widget.find('[data-ui-field=bStay]').on('click', function () {
                HG.Control.Modules.ServiceCall("QuickAccess", module.Domain, module.Address, "Stay", function (data) { });
            });
            widget.find('[data-ui-field=bInstant]').on('click', function () {
                HG.Control.Modules.ServiceCall("QuickAccess", module.Domain, module.Address, "Instant", function (data) { });
            });
            widget.find('[data-ui-field=bMax]').on('click', function () {
                HG.Control.Modules.ServiceCall("QuickAccess", module.Domain, module.Address, "Max", function (data) { });
            });
            widget.find('[data-ui-field=bChime]').on('click', function () {
                HG.Control.Modules.ServiceCall("QuickAccess", module.Domain, module.Address, "Chime", function (data) { });
            });


            // settings button
            widget.find('[data-ui-field=settings]').on('click', function () {
                HG.WebApp.ProgramEdit._CurrentProgram.Domain = module.Domain;
                HG.WebApp.ProgramEdit._CurrentProgram.Address = module.Address;
                HG.WebApp.ProgramsList.UpdateOptionsPopup();
            });
        }

        this.GroupName = container.attr('data-context-group');

        var alarmConnection = HG.WebApp.Utility.GetModulePropertyByName(module, "AlarmPanel.Connection");
        this.StatusText = alarmConnection.Value;

        var alarmStatus = HG.WebApp.Utility.GetModulePropertyByName(module, "AlarmPanel.Status");
        this.Description = alarmStatus.Value;
         




        //var armedstatus = HG.WebApp.Utility.GetModulePropertyByName(module, "Status.Level"); //HG.WebApp.Utility.GetModulePropertyByName(module, "HomeGenie.SecurityArmed");
        //if (armedstatus != null && armedstatus.Value == "1") {
        //    widget.find('[data-ui-field=armdisarm]').val("on").slider('refresh');
        //}
        //else {
        //    widget.find('[data-ui-field=armdisarm]').val("off").slider('refresh');
        //}

        //var armedlevel = HG.WebApp.Utility.GetModulePropertyByName(module, "Status.Level");
        //var armedstatus = HG.WebApp.Utility.GetModulePropertyByName(module, "HomeGenie.SecurityArmed");
        //if (armedlevel != null && armedlevel.Value == "1") {
        //    if (armedstatus != null && armedstatus.Value == "1") {
        //        this.Description = "ARMED";
        //    }
        //    else {
        //        this.Description = "ARMING...";
        //    }
        //}
        //else {
        //    this.Description = "DISARMED";
        //}

        //
        // render widget
        //
        widget.find('[data-ui-field=name]').html(module.Name);
        widget.find('[data-ui-field=icon]').attr('src', this.IconImage);
        widget.find('[data-ui-field=status]').html('<span style="vertical-align:middle">' + this.StatusText + '</span>');
        widget.find('[data-ui-field=description]').html(this.Description);
    }

}]
