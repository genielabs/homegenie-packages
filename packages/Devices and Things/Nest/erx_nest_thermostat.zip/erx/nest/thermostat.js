[{
    Name: "Nest Thermostat Widget : base on generic thermostat",
    Author: "Eric Sauv??",
    Version: "2016-01-24",

    GroupName: '',
    IconImage: 'pages/control/widgets/erx/nest/images/thermostat.png',
    StatusText: '',
    Description: '',

    levelKnobBindValue: 'SetPoint',
    levelKnobValue: 0,
    RenderView: function (cuid, module) {

        var container = $(cuid);
        var widget = container.find('[data-ui-field=widget]');
        var controlpopup = widget.data('ControlPopUp');
        var _this = this;
        //var knobvalue = 0;

        if (!controlpopup) {

            container.find('[data-ui-field=controlpopup]').trigger('create');
            controlpopup = container.find('[data-ui-field=controlpopup]').popup();
            widget.data('ControlPopUp', controlpopup);

            widget.find('[data-ui-field=options]').on('click', function () {
                if ($(cuid).find('[data-ui-field=widget]').data('ControlPopUp')) {
                    $(cuid).find('[data-ui-field=widget]').data('ControlPopUp').popup('open');
                }
            });

            controlpopup.find('[data-ui-field=level_knob]').knob({
                'release': function (v) {
                    //To do Validate Max Min between Low and High
                    levelKnobValue = Math.round(v * 10) / 10;
				  	_this.UpdateSetPoint(levelKnobValue, module, controlpopup);
                },
                'change': function (v) {
                    //levelKnobValue = Math.round(v * 10) / 10;
                }
            });

            if (HG.WebApp.Locales.GetTemperatureUnit() == 'Celsius') {
                controlpopup.find('[data-ui-field=level_knob]').trigger('configure', {
                    min: 5,
                    max: 35,
                    step: 0.5
                });
            }
            else {
                controlpopup.find('[data-ui-field=level_knob]').trigger('configure', {
                    min: 40,
                    max: 100,
                    step: 1
                });
            }

            // settings button
            widget.find('[data-ui-field=settings]').on('click', function () {
                if (module.Domain == 'HomeAutomation.HomeGenie.Automation') {
                    HG.WebApp.ProgramEdit._CurrentProgram.Domain = module.Domain;
                    HG.WebApp.ProgramEdit._CurrentProgram.Address = module.Address;
                    HG.WebApp.ProgramsList.UpdateOptionsPopup();
                }
                else {
                    HG.WebApp.Control.EditModule(module);
                }
            });

            // popup values on open
            controlpopup.on('popupbeforeposition', function (evt, ui) {
                // reset buttons' state
                controlpopup.find('[data-ui-field=mode_off]').addClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_cool]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_heat]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_coolheat]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_eco]').removeClass('ui-btn-active');
                
                // thermostat mode
                var thermostatMode = HG.WebApp.Utility.GetModulePropertyByName(module, 'Thermostat.Mode');
                if (thermostatMode != null) {
                    if (thermostatMode.Value == 'Cool') {
                        controlpopup.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
                        controlpopup.find('[data-ui-field=mode_cool]').addClass('ui-btn-active');
                        _this.EditSetPoint(controlpopup, module);
                    }
                    else if (thermostatMode.Value == 'Heat') {
                        controlpopup.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
                        controlpopup.find('[data-ui-field=mode_heat]').addClass('ui-btn-active');
                        _this.EditSetPoint(controlpopup, module);
                    }
                    else if (thermostatMode.Value == 'Auto') {
                        controlpopup.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
                        controlpopup.find('[data-ui-field=mode_coolheat]').addClass('ui-btn-active');
                        _this.EditLowSetPoint(controlpopup, module, thermostatMode.Value);
                    }
                    else if (thermostatMode.Value == 'Eco') {
                        controlpopup.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
                        controlpopup.find('[data-ui-field=mode_eco]').addClass('ui-btn-active');
                        _this.EditOffSetPoint(controlpopup, module);
                    }
                    else {
                        _this.EditOffSetPoint(controlpopup, module);
                    }
                }
                
                // fan mode
                controlpopup.find('[data-ui-field=fanmode_auto]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=fanmode_circulate]').removeClass('ui-btn-active');
                var fanMode = HG.WebApp.Utility.GetModulePropertyByName(module, 'Thermostat.FanMode');
                if (fanMode != null) {
                    if (fanMode.Value == 'Auto') {
                        controlpopup.find('[data-ui-field=fanmode_auto]').addClass('ui-btn-active');
                    }
                    else if (fanMode.Value == 'Circulate') {
                        controlpopup.find('[data-ui-field=fanmode_circulate]').addClass('ui-btn-active');
                    }
                }
            });
            
            // set point buttons events
            controlpopup.find('[data-ui-field=dn_setpoint]').on('click', function () {
              levelKnobValue = levelKnobValue - 0.5;
              controlpopup.find('[data-ui-field=level_knob]').val(levelKnobValue).trigger('change')
			  _this.UpdateSetPoint(levelKnobValue, module, controlpopup);
            });
            controlpopup.find('[data-ui-field=up_setpoint]').on('click', function () {
              levelKnobValue = levelKnobValue + 0.5;
              controlpopup.find('[data-ui-field=level_knob]').val(levelKnobValue).trigger('change')
			  _this.UpdateSetPoint(levelKnobValue, module, controlpopup);
            });
            controlpopup.find('[data-ui-field=high_setpoint]').on('click', function () {
                _this.EditHighSetPoint(controlpopup, module);
            });
            controlpopup.find('[data-ui-field=low_setpoint]').on('click', function () {
                _this.EditLowSetPoint(controlpopup, module);
            });
            controlpopup.find('[data-ui-field=setpoint]').on('click', function () {
                _this.EditSetPoint(controlpopup, module);
            });
            // thermostat mode buttons events
            controlpopup.find('[data-ui-field=mode_off]').on('click', function () {
                controlpopup.find('[data-ui-field=mode_off]').addClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_cool]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_heat]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_coolheat]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_eco]').removeClass('ui-btn-active');
                _this.EditOffSetPoint(controlpopup, module);
                HG.Control.Modules.ServiceCall("Thermostat.ModeSet", module.Domain, module.Address, "off", function (data) { });
            });
            controlpopup.find('[data-ui-field=mode_cool]').on('click', function () {
                controlpopup.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_cool]').addClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_heat]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_coolheat]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_eco]').removeClass('ui-btn-active');
                _this.EditSetPoint(controlpopup, module);
                HG.Control.Modules.ServiceCall("Thermostat.ModeSet", module.Domain, module.Address, "cool", function (data) { });
            });
            controlpopup.find('[data-ui-field=mode_heat]').on('click', function () {
                controlpopup.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_cool]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_heat]').addClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_coolheat]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_eco]').removeClass('ui-btn-active');
                _this.EditSetPoint(controlpopup, module);
                HG.Control.Modules.ServiceCall("Thermostat.ModeSet", module.Domain, module.Address, "heat", function (data) { });
            });
            controlpopup.find('[data-ui-field=mode_coolheat]').on('click', function () {
                controlpopup.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_cool]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_heat]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_coolheat]').addClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_eco]').removeClass('ui-btn-active');
                _this.EditLowSetPoint(controlpopup, module);
                HG.Control.Modules.ServiceCall("Thermostat.ModeSet", module.Domain, module.Address, "heat-cool", function (data) { });
            });
            controlpopup.find('[data-ui-field=mode_eco]').on('click', function () {
                controlpopup.find('[data-ui-field=mode_off]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_cool]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_heat]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_coolheat]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=mode_eco]').addClass('ui-btn-active');
                _this.EditOffSetPoint(controlpopup, module);
                HG.Control.Modules.ServiceCall("Thermostat.ModeSet", module.Domain, module.Address, "eco", function (data) { });
            });
            
            // thermostate fan button events
            controlpopup.find('[data-ui-field=fanmode_auto]').on('click', function () {
                controlpopup.find('[data-ui-field=fanmode_auto]').addClass('ui-btn-active');
                controlpopup.find('[data-ui-field=fanmode_circulate]').removeClass('ui-btn-active');
                HG.Control.Modules.ServiceCall("Thermostat.FanModeSet", module.Domain, module.Address, "Auto", function (data) { });
            });
            controlpopup.find('[data-ui-field=fanmode_circulate]').on('click', function () {
                controlpopup.find('[data-ui-field=fanmode_auto]').removeClass('ui-btn-active');
                controlpopup.find('[data-ui-field=fanmode_circulate]').addClass('ui-btn-active');
                HG.Control.Modules.ServiceCall("Thermostat.FanModeSet", module.Domain, module.Address, "Circulate", function (data) { });
            });

        }
        
        this.Description = (module.Domain.substring(module.Domain.lastIndexOf('.') + 1)) + ' ' + module.Address;

        widget.find('[data-ui-field=name]').html(module.Name);
        widget.find('[data-ui-field=description]').html(this.Description);
        controlpopup.find('[data-ui-field=group]').html(this.GroupName);
        controlpopup.find('[data-ui-field=name]').html(module.Name);

        var imagesrc = 'pages/control/widgets/homegenie/generic/images/temperature.png';

        // display Temperature
        var temperatureField = HG.WebApp.Utility.GetModulePropertyByName(module, "Sensor.Temperature");
        var temperature = 0;
        if (temperatureField != null) {
            temperature = temperatureField.Value.replace(',', '.');
            widget.find('[data-ui-field=temperature_value]').html(HG.WebApp.Utility.FormatTemperature(temperature));
        } else {
            widget.find('[data-ui-field=temperature_value]').html('');
        }

        // display Humidity
        var humidityField = HG.WebApp.Utility.GetModulePropertyByName(module, "Sensor.Humidity");
        var humidity = 0;
        if (humidityField != null) {
            humidity = humidityField.Value.replace(',', '.');
            widget.find('[data-ui-field=humidity_value]').html(humidity + "%");
        } else {
            widget.find('[data-ui-field=humidity_value]').html('');
        }

      
        // display Fan State
        var fanState = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.FanState");
        if (fanState == null || fanState.Value == '') {
            widget.find('[data-ui-field=fan_field]').hide();
        }
        else {
            widget.find('[data-ui-field=fan_field]').show();
            var displayFan = '---';
            switch (fanState.Value) {
                case 'Running':
                case 'Circulate':
                    displayFan = 'On';
                    break;
                default:
                    displayFan = 'Off';
                    break;
            }
            widget.find('[data-ui-field=fan_value]').html(displayFan);
        }

        // display status line (operating state + mode)
        var displayState = '---';
        var operatingState = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.OperatingState");
        if (operatingState != null) displayState = operatingState.Value;
        widget.find('[data-ui-field=operating_value]').html(displayState);
        switch (displayState) {
            case 'Heating' :
              widget.css("background-color", "#FF2200");
              break;
            case 'Cooling' :
              widget.css("background-color", "#0022FF");
              break;
            default :widget.css("background-color", "");
        }
        //
        var displayMode = '---';
        var operatingMode = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.Mode");
        if (operatingMode != null) displayMode = operatingMode.Value;
        widget.find('[data-ui-field=mode_value]').html(displayMode);

        // display current Heating SetPoint
        var heatTo = null;
        if (displayMode == 'Auto') heatTo = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.SetPoint.LowSetPoint");
        if (displayMode == 'Heat') heatTo = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.SetPoint.SetPoint");
        if (displayMode == 'Eco') heatTo = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.SetPoint.ecoLowSetPoint");;
        if (heatTo == null || heatTo.Value == '') {
            widget.find('[data-ui-field=heat_field]').hide();
        }
        else {
            widget.find('[data-ui-field=heat_field]').show();
            s = heatTo.Value + " ";
            s = s.replace(',', '.');
            var temperature = Math.round(s * 100) / 100;
            widget.find('[data-ui-field=heatset_value]').html(temperature.toFixed(1) + '&deg;');
        }


        // display current Cooling SetPoint
        widget.find('[data-ui-field=cool_field]').hide();
        var coolTo = null;
        if (displayMode == 'Auto') coolTo = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.SetPoint.HighSetPoint");
        if (displayMode == 'Cool') coolTo = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.SetPoint.SetPoint");
        if (displayMode == 'Eco') coolTo = HG.WebApp.Utility.GetModulePropertyByName(module, "Thermostat.SetPoint.ecoHighSetPoint");
        if (coolTo == null || coolTo.Value == '') {
            widget.find('[data-ui-field=cool_field]').hide();
        }
        else {
            widget.find('[data-ui-field=cool_field]').show();
            s = coolTo.Value + " ";
            s = s.replace(',', '.');
            var temperature = Math.round(s * 100) / 100;
            //var temperature = Math.round(coolTo.Value.replace(',', '.') * 100) / 100;
            widget.find('[data-ui-field=coolset_value]').html(temperature.toFixed(1) + '&deg;');
        }
    },

    EditLowSetPoint: function (controlpopup, module) {
        var levelKnob = controlpopup.find('[data-ui-field=level_knob]');
        controlpopup.find('[id=knobgrp]').show();
        controlpopup.find('[data-ui-field=high_setpoint]').removeClass('ui-btn-active');
        controlpopup.find('[data-ui-field=setpoint]').removeClass('ui-btn-active');
        controlpopup.find('[data-ui-field=low_setpoint]').addClass('ui-btn-active');
        controlpopup.find('[id=setpointgrp]').hide();
        controlpopup.find('[id=lowhighgrp]').show();

        // show current cool setpoint
        var lowSetPoint = HG.WebApp.Utility.GetModulePropertyByName(module, 'Thermostat.SetPoint.LowSetPoint');
        if (lowSetPoint != null) {
            levelKnob.val(lowSetPoint.Value).trigger('change');
            levelKnobValue = Math.round(lowSetPoint.Value * 10) / 10;
        }
        this.levelKnobBindValue = 'LowSetPoint';
    },

    EditHighSetPoint: function (controlpopup, module) {
        var levelKnob = controlpopup.find('[data-ui-field=level_knob]');
        controlpopup.find('[id=knobgrp]').show();
        controlpopup.find('[data-ui-field=low_setpoint]').removeClass('ui-btn-active');
        controlpopup.find('[data-ui-field=setpoint]').removeClass('ui-btn-active');
        controlpopup.find('[data-ui-field=high_setpoint]').addClass('ui-btn-active');
        controlpopup.find('[id=setpointgrp]').hide();
        controlpopup.find('[id=lowhighgrp]').show();
        // show current heat setpoint
        var highSetPoint = HG.WebApp.Utility.GetModulePropertyByName(module, 'Thermostat.SetPoint.HighSetPoint');
        if (highSetPoint != null) {
            levelKnob.val(highSetPoint.Value).trigger('change');
            levelKnobValue = Math.round(highSetPoint.Value * 10) / 10;
        }
        this.levelKnobBindValue = 'HighSetPoint';
    },
    
    EditSetPoint: function (controlpopup, module) {
        var levelKnob = controlpopup.find('[data-ui-field=level_knob]');
        controlpopup.find('[id=knobgrp]').show();
        controlpopup.find('[data-ui-field=low_setpoint]').removeClass('ui-btn-active');
        controlpopup.find('[data-ui-field=high_setpoint]').removeClass('ui-btn-active');
        controlpopup.find('[data-ui-field=setpoint]').addClass('ui-btn-active');
        controlpopup.find('[id=setpointgrp]').show();
        controlpopup.find('[id=lowhighgrp]').hide();
        // show current heat setpoint
        var SetPoint = HG.WebApp.Utility.GetModulePropertyByName(module, 'Thermostat.SetPoint.SetPoint');
        if (SetPoint != null) {
            levelKnob.val(SetPoint.Value).trigger('change');
            levelKnobValue =  Math.round(SetPoint.Value * 10) / 10;
            //controlpopup.find('[data-ui-field=status]').html(heatSetPoint.Value + '&deg;');
        }
        this.levelKnobBindValue = 'SetPoint';
    },
  
    EditOffSetPoint: function (controlpopup, module) {
        var levelKnob = controlpopup.find('[data-ui-field=level_knob]');
        controlpopup.find('[id=knobgrp]').hide();
    },

    UpdateSetPoint: function (value, module, controlpopup) {
       // add calidation for min max 
       if (this.levelKnobBindValue == 'HighSetPoint') {
         var lowSetPoint = HG.WebApp.Utility.GetModulePropertyByName(module, 'Thermostat.SetPoint.LowSetPoint');
         if (lowSetPoint != null) {
           var val = (Math.round((lowSetPoint.Value) * 10) / 10) + 1.5;
           if (value < val) {
             var levelKnob = controlpopup.find('[data-ui-field=level_knob]');
             value = val;
             levelKnob.val(value).trigger('change');
             levelKnobValue =  value;
           }
         }
       } else if (this.levelKnobBindValue == 'LowSetPoint') {
         var highSetPoint = HG.WebApp.Utility.GetModulePropertyByName(module, 'Thermostat.SetPoint.HighSetPoint');
         if (highSetPoint != null) {
           var val = (Math.round((highSetPoint.Value) * 10) / 10) - 1.5;
           if (value > val) {
             var levelKnob = controlpopup.find('[data-ui-field=level_knob]');
             value = val;
             levelKnob.val(value).trigger('change');
             levelKnobValue =  value;
           }
         }
       }
       var setPoint = HG.WebApp.Utility.GetModulePropertyByName(module, 'Thermostat.SetPoint.' + this.levelKnobBindValue);
       if (setPoint != null) setPoint.Value = value;
       HG.Control.Modules.ServiceCall('Thermostat.SetPointSet/' + this.levelKnobBindValue, module.Domain, module.Address, value, function (data) { });
    }

}]