$$.widget = {
  name: 'Nest Loggin',
  version: '1.0',
  author: 'Saue0',
  release: '2017-05-13',
  icon: 'pages/control/widgets/erx/nest/images/nest-icons-house.png'
};
$$.State = "";
/*
# Quick-Reference

 "$$" is the widget class instance object

 Widget class methods and properties:

 Get the jQuery element for a "data-ui" field
   $$.field('<widget_field_name>')

 Get the jQuery element in the main document
   $$.field('<document_tree_selector>', true)

 Call HG API Web Service 
   $$.apiCall('<api_method>', function(response){ ... })

 Get the bound module object
   $$.module

 Get a parameter of the bound module
   $$.module.prop('<param_name>')
   e.g.: $$.module.prop('Status.Level')

 Invoke a module command
   $$.module.command('<api_command>', '<command_options>', function(response) { ... })
   e.g.: $$.module.command('Control.Off')

 Shorthand for HG.Ui
   $$.ui

 Shorthand for HG.WebApp.Utility
   $$.util

 Shorthand for HG.WebApp.Locales
   $$.locales

 Blink a widget field and the status led image (if present)
   $$.signalActity('<widget_field_name>') 

 For a reference of HomeGenie Javascript API see:
   https://github.com/genielabs/HomeGenie/tree/master/BaseFiles/Common/html/js/api

*/

// Widget base class methods


// This method is called when the widget starts
$$.onStart = function() {
  // handle ui elements events
  $$.field('btn-pin').bind('click', function(){
    if ($$.module.prop('NestConnect').Value == 'Connected'){
      HG.WebApp.Utility.ConfirmPopup('Disconnected','Are you sure', function(proceed) {
        if (proceed) 
	      $$.apiCall('Disconnect','HomeAutomation.NestConfig','Connect','State');
        });
    }
    else {
  	  $$.State = (Math.random() + 1).toString(36).substring(7); 
  	  if ($$.module.prop('ConfigureOptions.UsePin').Value =="1") {
    	$$.popup.field('pin').val('');
	    $$.popup.field('status').html('');
    	$$.popup.field('message').html('');
      	$$.popup.popup('open');
      }
      else
	  	ExecuteAuthRequest();
    }
      
  });

  // When options button is clicked control popup is shown
  $$.popup.field('btn-pin').on('click', function () {
	ExecuteAuthRequest();
  });

  $$.field('settings').on('click', function () {
	$$.ui.ConfigureProgram($$.module);
  });

  // Popup buttons click
  $$.popup.field('btn-pinok').on('click', function () {
    $$.popup.field('status').html('Working');
    $$.popup.field('message').html('');
    $$.apiCall($$.State,'HomeAutomation.NestConfig','Pin',$$.popup.field('pin').val(),function(response) {
      if (response['ResponseValue'] != 'OK') {
        $$.popup.field('status').html(response['ResponseValue']);
        $$.popup.field('message').html(response['Message']);
      }
      else
        $$.popup.popup('close');
    }); 
  });
}

// This method is called when the widget UI is request to refresh its view
$$.onRefresh = function () {
  $$.field('name').html($$.module.Name + " (" + $$.module.DeviceType + ")");
  $$.popup.field('name').html($$.module.Name);
  $$.field('description').html('Login Info');
  $$.field('info').html('Help set authorisation');
  $$.field('status').html('...');
  $$.field('connectstatus').html($$.module.prop('NestConnect').Value);
  if ($$.module.prop('NestConnect').Value == 'Connected'){
    $$.field('led').attr('src', 'images/common/led_green.png');
    $$.field('btn-pin').html('Logout');
  }
  else if ($$.module.prop('NestConnect').Value == 'Disconnected'){
    $$.field('led').attr('src', 'images/common/led_red.png');  
    $$.field('btn-pin').html('Login');
  }
  else{
    $$.field('led').attr('src', 'images/common/led_yellow.png');
  }
}

// This method is called when the bound module raises a parameter event
// eg.: parameter = 'Status.Level', value = '1'
$$.onUpdate = function(parameter, value) {
}

// This method is called when the widget stops
$$.onStop = function() {
}

// user-defined methods implemented for this widget
ExecuteAuthRequest = function() {
    $$.module.prop('NestState').Value =$$.State;
    $$.apiCall('NestState','HomeAutomation.NestConfig','Config',$$.State); 
    var url = $$.module.prop('NestAuthUrl').Value.format(
      $$.module.prop('ConfigureOptions.NestClientID').Value,
      $$.module.prop('NestState').Value);
	window.open(url,'_blank');
};

String.prototype.format = function() {
    var formatted = this;
    for( var arg in arguments ) {
        formatted = formatted.replace("{" + arg + "}", arguments[arg]);
    }
    return formatted;
};


