$$.widget = {
  name: 'Nest Loggin',
  version: '1.0',
  author: 'Saue0',
  release: '2017-05-13',
  icon: 'pages/control/widgets/erx/nest/images/nest-icons-house.png'
};
$$.State = "";  

/*
# Quick-Reference

 "$$" is the widget class instance object

 Widget class methods and properties:

 Get the jQuery element for a "data-ui" field
   $$.field('<widget_field_name>')

 Get the jQuery element in the main document
   $$.field('<document_tree_selector>', true)

 Call HG API Web Service 
   $$.apiCall('<api_method>', function(response){ ... })

 Get the bound module object
   $$.module

 Get a parameter of the bound module
   $$.module.prop('<param_name>')
   e.g.: $$.module.prop('Status.Level')

 Invoke a module command
   $$.module.command('<api_command>', '<command_options>', function(response) { ... })
   e.g.: $$.module.command('Control.Off')

 Shorthand for HG.Ui
   $$.ui

 Shorthand for HG.WebApp.Utility
   $$.util

 Shorthand for HG.WebApp.Locales
   $$.locales

 Blink a widget field and the status led image (if present)
   $$.signalActity('<widget_field_name>') 

 For a reference of HomeGenie Javascript API see:
   https://github.com/genielabs/HomeGenie/tree/master/BaseFiles/Common/html/js/api

*/

// Widget base class methods


// This method is called when the widget starts
$$.onStart = function() {


  // handle ui elements events
  $$.field('btn-pin').bind('click', function(){
    if ($$.module.prop('NestConnect').Value == 'Connected'){
      HG.WebApp.Utility.ConfirmPopup('Disconnected','Are you sure', function(proceed) {
        if (proceed) 
	      $$.apiCall('Disconnect','HomeAutomation.NestConfig','Connect','State');
        });
    }
    else {
  	  $$.State = (Math.random() + 1).toString(36).substring(7); 
  	  if ($$.module.prop('ConfigureOptions.UsePin').Value =="1") {
        $$.popup.field('pingrp').show();
        $$.popup.field('statgrp').hide();
    	$$.popup.field('pin').val('');
	    $$.popup.field('status').html('');
    	$$.popup.field('message').html('');
      	$$.popup.popup('open');
      }
      else
	  	ExecuteAuthRequest();
    }
      
  });

         $$.popup.field('mytempstats').qtip({
            id: 'flot',
            show: false,
            prerender: true,
            content: ' ',
            position: {
				target: 'mouse',
                adjust: {x:5,y:5}
            }
        });
		
        $$.popup.field('mytempstats').bind("plothover", function (event, pos, item) {
            // Grab the API reference
            var graph = $$.popup.field('mytempstats'),
                api = graph.qtip(),
                previousPoint;
				
            // If we weren't passed the item object, hide the tooltip and remove cached point data
            if (!item) {
				if (api.cache.point != false) api.hide();
                api.cache.point = false;
            } else {
				previousPoint = api.cache.point;
				if (previousPoint != item.dataIndex) {
					var offset = new Date().getTimezoneOffset() * 60 * 1000;
					api.cache.point = item.dataIndex;
					api.set('content.text',
						item.series.label + " at " 
							+ new Date(item.datapoint[0] + offset).toLocaleTimeString()
							+ " = " + item.datapoint[1].toFixed(2));
					api.elements.tooltip.stop(1, 1);
					api.show(item);
				}
			}
        });
   
 
  // When options button is clicked control popup is shown
  $$.popup.field('btn-pin').on('click', function () {
	ExecuteAuthRequest();
  });

  $$.field('settings').on('click', function () {
    $$.popup.field('pingrp').show();
    $$.popup.field('statgrp').hide();
    $$.popup.addClass('hg-popup-a');
    $$.popup.removeClass('hg-popup-c');
      	$$.popup.popup('open');
//	$$.ui.ConfigureProgram($$.module);
  });
  
  $$.field('my_analyze').on('click', function () {
    $$.popup.field('pingrp').hide();
    $$.popup.field('statgrp').show();
    $$.popup.addClass('hg-popup-c');
    $$.popup.removeClass('hg-popup-a');
    RefreshStat();
      	$$.popup.popup('open');
  });

  // Popup buttons click
  $$.popup.field('btn-pinok').on('click', function () {
    $$.popup.field('status').html('Working');
    $$.popup.field('message').html('');
    $$.apiCall($$.State,'HomeAutomation.NestConfig','Pin',$$.popup.field('pin').val(),function(response) {
      if (response['ResponseValue'] != 'OK') {
        $$.popup.field('status').html(response['ResponseValue']);
        $$.popup.field('message').html(response['Message']);
      }
      else
        $$.popup.popup('close');
    }); 
  });
}

// This method is called when the widget UI is request to refresh its view
$$.onRefresh = function () {
  $$.field('name').html($$.module.Name + " (" + $$.module.DeviceType + ")");
  $$.popup.field('name').html($$.module.Name);
  $$.field('description').html('Login Info');
  $$.field('info').html('Help set authorisation');
  $$.field('status').html('...');
  $$.field('connectstatus').html($$.module.prop('NestConnect').Value);
  if ($$.module.prop('NestConnect').Value == 'Connected'){
    $$.field('led').attr('src', 'images/common/led_green.png');
    $$.field('btn-pin').html('Logout');
  }
  else if ($$.module.prop('NestConnect').Value == 'Disconnected'){
    $$.field('led').attr('src', 'images/common/led_red.png');  
    $$.field('btn-pin').html('Login');
  }
  else{
    $$.field('led').attr('src', 'images/common/led_yellow.png');
  }
}

// This method is called when the bound module raises a parameter event
// eg.: parameter = 'Status.Level', value = '1'
$$.onUpdate = function(parameter, value) {
}

// This method is called when the widget stops
$$.onStop = function() {
}

// user-defined methods implemented for this widget
ExecuteAuthRequest = function() {
    $$.module.prop('NestState').Value =$$.State;
    $$.apiCall('NestState','HomeAutomation.NestConfig','Config',$$.State); 
    var url = $$.module.prop('NestAuthUrl').Value.format(
      $$.module.prop('ConfigureOptions.NestClientID').Value,
      $$.module.prop('NestState').Value);
	window.open(url,'_blank');
};

String.prototype.format = function() {
    var formatted = this;
    for( var arg in arguments ) {
        formatted = formatted.replace("{" + arg + "}", arguments[arg]);
    }
    return formatted;
};	

RefreshStat = function () {
    var _this = this;
    var showsplines = false;
    var showlines = false;
    var showbars = true;
    var to = new Date();
    var from = new Date(to - 24 * 60 * 60);
	var aTemperature;
	var aHumidity;
	var aOperatingState;
    from.setDate(to.getDate() - 1);
	$.when(
		$.ajax({
			url: '/' + HG.WebApp.Data.ServiceKey 
			         + '/HomeAutomation.HomeGenie/Statistics/Parameter.StatsMultiple/Sensor.Temperature/All:/' 
					 + from.getTime() + '/' + to.getTime(),
			type: 'GET',
			dataType: 'json',
			success: function (data) { aTemperature = data; }}),
		$.ajax({
			url: '/' + HG.WebApp.Data.ServiceKey 
					 + '/HomeAutomation.HomeGenie/Statistics/Parameter.StatsMultiple/Sensor.Humidity/All:/' 
					 + from.getTime() + '/' + to.getTime(),
			type: 'GET',
			dataType: 'json',
			success: function (data) { aHumidity = data; }}),
		$.ajax({
			url: '/' + HG.WebApp.Data.ServiceKey 
					 + '/HomeAutomation.HomeGenie/Statistics/Parameter.StatsMultiple/Sensor.OperatingState/All:/' 
					 + from.getTime() + '/' + to.getTime(),
			type: 'GET',
			dataType: 'json',
			success: function (data) { aOperatingState = data; }})
	).done(function(){
		var name = '';
        var tformat = "";
        var tickSize = "";
        var graph_data = [];
        var stats;
                          
        tformat = "%h:00";
        tickSize = "hour";
        stats = eval(aOperatingState);
        $.each(stats, function (index, val) {
			if (index % 2)
				graph_data.push({
					label: name,
					data: val,
					color: "#000000",
					lines: {show: true, 
						lineWidth: 2.0, 
						fill: true,
						//fillColor: { colors: [ {opacity: 1.0 }, {opacity: 0.5 } ] }},
						fillColor: { 
							colors: ['rgba(0,0,255, 0.2)', 'rgba(255,255,255, 0.2)', 'rgba(255,0,0, 0.2)']  
						}
					},
					bars: {show: false},
					splines: {show: false},
					points: {show: false},
					yaxis: 3
                });
            else
				name = 'Oper - ' + val;
            });        
        stats = eval(aTemperature);
        $.each(stats, function (index, val) {
			if (index % 2)
				graph_data.push({
					label: name,
					data: val,
					lines: {show: true, lineWidth: 2.0},
					bars: {show: false},
					splines: {show: false},
					points: {show: false},
                });
            else
				name = 'Temp - ' + val;
            });
        stats = eval(aHumidity);
        $.each(stats, function (index, val) {
			if (index % 2)
				graph_data.push({
					label: name,
					data: val,
					lines: {show: true, lineWidth: 2.0},
					bars: {show: false},
					splines: {show: false},
					points: {show: false},
					yaxis: 2
                });
            else
				name = 'Humid - ' + val;
            });        
		$.plot($$.popup.field('mytempstats'), graph_data, {
            yaxes: [{show: true, position: 'left'},
					{show: true, position: 'right'},
					{show: true, 
					 tickSize: 1,
					 min: -1.1, max:2.1,
					 tickFormatter: function(val, axis) { return val == -1 ? "Cooling" : val == 0 ? "Off" : val == 1 ? "Heating" : val == 2 ? "Emergency" : "";}}],
			xaxis: {
				mode: "time",
                timeformat: tformat,
                minTickSize: [1, tickSize],
                tickSize: [3, tickSize]
            },
            legend: {show :false},
            grid: {
              color: 'black',
//              backgroundColor: 'rgba(255,255,255, 0.2)',
              hoverable: true
            },
            points: {show: true},
            zoom: {interactive: true},
            pan: {interactive: true}
        });
    }
	)
	};

