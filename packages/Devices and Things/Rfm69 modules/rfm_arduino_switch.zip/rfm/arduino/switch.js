$$.widget = {
  name: 'Rfm switch',
  version: '1.07',
  author: 'Wolfgang Otto',
  release: '2016-09-17',
  icon: 'pages/control/widgets/rfm/images/wifi_off.png',
  processImages: ['pages/control/widgets/homegenie/generic/images/light_off.png','pages/control/widgets/homegenie/generic/images/light_on.png'],
};

// protocol string length constants
// 2016-09-16T12:50:03+02:00 ; {"Name":"Car Heating","Address":"1","Node":"86","Port":"A4","Command":"Off","Duration":"0"} (DEMO)
// ^------ time -----^         ^--------------------------- JSON string -------------------------------------------------^
const timelen = 19, textbegin = 28;

// Buffer variables for Node, Boardtype, Pin, IconOn, IconOff, ...
var v_Node,v_Board,v_Port,v_Duration, v_IconOn, v_IconOff;
var updateTime = '';
var isOnIcon;
var boardlist = null;
var DialogLog = null;
var infolist = null; 

//
// Variables for flot graph
//
var plotflot = null;
var plotarea = null;
var series = [];
var lastminDate = null;
var lastmaxDate = null;
var minDate =null;
var maxDate = null;
var selectedZoom = null;

var TimeDimension = {"Year":1, "Quarter":2, "Month":3, "Week":4, "Day":5, "Hour":6, "Earlier":7, "Later":8, "Now":9 };
var dayOfWeek = {
  en: ["Sun", "Mon", "Tue", "Wed", "Thr", "Fri", "Sat"],
  de: ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"],
}

var monthArray = {
  de: ["Jan","Feb","Mär","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"],
  en: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
  fr: ["Jan","Fév","Mar","Avr","Mai","Juin","Juil","Aout","Sep","Oct","Nov","Déc"],
  it: ["Gen","Feb","Mar","Apr","Mag","Giu","Lug","Ago","Set","Ott","Nov","Dic"],
}

var options = {
    series: {
      	lines: {
          show: true,
		  fill: true,
          steps: true,
          shadowSize: 0
		},
    },
    xaxis: {
			mode: "time",
      		monthNames: monthArray[$$.locales.GetUserLanguage()],
      		useLocalTime: true,
      		timeformat: "%H:%M %d.%0m",      		
    },
    yaxis: { 
      	min: 0,
        color: "white",
        tickDecimals: 1
    },
    legend: { 
      	position: "ne",
      	labelFormatter: function (label, series) {
            return "<font color=\"white\">" + label + "</font>";
        },
      	noColumns: 0, 
      	backgroundColor: "transparent",
        backgroundOpacity: 0.9,
    },  	
    selection: {
		mode: "x"
	},
  
  	//zoom: {	interactive: true },
	// pan: {	interactive: true }
  };
 
$$.plotlog = function () {
  
  var plotData = []; //Flot JS format, which contains pairs of {label, array}
  // Reset series again to delete old entries after filter change
  series.length = 0;
  
  var json = null;
  var colors = ["LightSeaGreen","Yellowgreen", "IndianRed", "Aquamarine", "Blue","Green", "Grey", "Yellow", "AntiqueWhite"];
  var v = [];

  var filterItems = DialogLog.find('ul li:not(.ui-screen-hidden)');
  //
  // extract DateTime, module address and status value from list item text, which is filled from RfmSwitch.log file
  // only lines with a valid Json string are used for the graph 'flot' plot
  //
  for (i = 0; i < filterItems.length; i++) {
    var t = filterItems[i].textContent;
    //
    // Get time stamp of log item
    // this is a ISO 8601 conform time string like 2016-09-13T11:23:57
    //
    var cc = new Date(t.substring(0,timelen)); // this is the UTC time like 2016-09-13T13:23:57 which i don't want to have  
    var unixtime = new Date(cc.getTime());
    
    // save the original data min and max datetime values to use them later on
    if (minDate == null) minDate = unixtime;
    if (maxDate == null) maxDate = unixtime;
    if (unixtime < minDate) minDate = unixtime;
    if (unixtime > maxDate) maxDate = unixtime;
    
    //
    // Create data array for each module with timestamp and value
    // plotData : Array[n] 		<-- array for all used virtual modules
    // 	0: Array[m]				<-- array for module 1 (address -1)
    //		0: "[1473755509,1]" <-- switch on at ...
    //		1: "[1473755512,0]" <-- switch off at ...
    // 		2: "[1473758575,1]" <-- switch on
    //		3: "[1473758637,0]" <-- switch off
    //
    
    try
      {
        var js = t.substring(t.indexOf("{"),t.indexOf("}")+1); 
        json = JSON.parse(js);        
        if ((typeof json.Address !== 'undefined') && (typeof json.Name !== 'undefined') && (typeof json.Command !== 'undefined') && isNaN(unixtime)==false)
          {
            var adr = json.Address - 1;            
            
            if (plotData[adr] == null) {  // Error this does not work correctly
              plotData[adr] = []; 
            }
            
            v = [];
            	v.push(unixtime);
            	v.push(json.Command =='Off' ? 0:1);
            plotData[adr].push(v);

            var found = false;         
            series.forEach(function(item){ if (item.label == json.Name) { found = true; return; }});
            if (found == false)
              {  
                var serie = {};
                	serie.address = adr;
                	serie.label = json.Name;
                	serie.color = colors[adr];
                	serie.data = plotData[adr];
                	serie.points = {fillColor: colors[adr], show: true};
                	serie.bars = { show: true, lineWidth: 2, fill: true };
                series.push(serie);
              }
            } 
      }
    catch (err){}
  }

// sort the data series by address of subarray
series.sort(function (a, b) {
    return a.address - b.address;
});
  
if (plotflot == null) // initialize the 
   {
     plotflot = $.plot(plotarea, series, options);
   }
else
  {
    plotflot.setData(series);
	plotflot.setupGrid(); //only necessary if your new data will change the axes or grid
	plotflot.draw();
  }
  lastminDate = plotflot.getAxes().xaxis.min;
  lastmaxDate = plotflot.getAxes().xaxis.max;
  selectedZoom=TimeDimension.Now;
}

$$.onStart = function() {

  $$.loadBoardlist();	// get board and pin configuration as json object from server
  //
  // dialog stuff to open the logbook dialog
  //
  DialogLog = $$.container.find('[data-ui-field="dialogpopup"]').popup();
  DialogLog.trigger('create');
  
  plotarea = DialogLog.find('[data-ui-field="placeholder"]'); 
  
  // BEGIN NAVIGATION, perhaps someone knows how to make that working
  // Navigation does NOT work up to now
  /*
  function addArrow(dir, right, top, offset) {
    
    var item = $("<img class='button' src='pages/control/widgets/rfm/images/arrow-" + dir + ".gif' style='z-index: 100; right:" + right + "px;top:" + top + "px'>");
    item.on('click', function(e){
               	e.preventDefault();
				plotflot.pan(offset);
            });
    item.appendTo(plotarea);
  }
  addArrow("left", 55, 60, { left: -100 });
  addArrow("right", 25, 60, { left: 100 });
  addArrow("up", 40, 45, { top: -100 });
  addArrow("down", 40, 75, { top: 100 });
  */
  // END NAVIGATION
  
  DialogLog.on( "filterablefilter", function( event, ui ) {   
    var count = $(this).find("ul li").length - $(this).find("ul .ui-screen-hidden").length;
    $(this).find('[data-ui-field="listcounter"]').html('Count: ' + count);
   
    // Plot new content
  	$$.plotlog();
  });
  
  DialogLog.find('[data-ui-field="dialog_close"]').on('click', function() {
  	$$.ui.SwitchPopup(DialogLog, $$.popup); 	
  });
  
  DialogLog.find('[data-ui-field="btn_refresh"]').on('click', function() {
    $$.getLoglist(); 
  });
  
  DialogLog.find('[data-ui-field="btn_year"]').on('click', function() { $$.plotGraph(TimeDimension.Year)});  		// Display the full current year
  DialogLog.find('[data-ui-field="btn_quarter"]').on('click', function() { $$.plotGraph(TimeDimension.Quarter)});	// Display the current quarter of a year
  DialogLog.find('[data-ui-field="btn_month"]').on('click', function() { $$.plotGraph(TimeDimension.Month)});  		// ... month
  DialogLog.find('[data-ui-field="btn_week"]').on('click', function() { $$.plotGraph(TimeDimension.Week)});  
  DialogLog.find('[data-ui-field="btn_day"]').on('click', function() { $$.plotGraph(TimeDimension.Day)});
  DialogLog.find('[data-ui-field="btn_Hour"]').on('click', function() { $$.plotGraph(TimeDimension.Hour)});
  DialogLog.find('[data-ui-field="btn_left"]').on('click', function() { $$.plotGraph(TimeDimension.Earlier)});		// shift timeline earlier (depends on hour, day, week, month, year)
  DialogLog.find('[data-ui-field="btn_right"]').on('click', function() { $$.plotGraph(TimeDimension.Later)}); 		// shift timeline later ...
  DialogLog.find('[data-ui-field="placeholder"]').dblclick(function () { $$.plotGraph(TimeDimension.Now)});			// reset the graph to starting values
  
  DialogLog.find('[data-ui-field="dialog_download"]').on('click', function() {
    var filterItems = DialogLog.find('ul li:not(.ui-screen-hidden)');
    
    // Attention: listview with filter attribute 
    var filterText = DialogLog.find('[data-ui-field="infolist"]').prev("form").find("input").val() +"*";   	  
   
	$.ajax({
    	//url: "js/FileSaver.js", // Switch this if you like to install js files inside HomeGenie base js path
      	url: "pages/control/widgets/rfm/arduino/js/FileSaver.js",
    	dataType: "script",
    	error: function(){
        	alert("Error: File saving not sucessfull, perhaps js/FileSaver.js missing!");
    	},
    	success: function(){
            var logs = [];
          	logs.push("Rfm switch protocol\r\n");
          	var d = new Date();
			var today = d.toLocaleDateString() + " " + d.toLocaleTimeString();
          	logs.push(today +"\r\n");
          	logs.push("Filter: " + filterText + "\r\n");
          	logs.push("---------------------------------------------------------------\r\n");
    		for (i = 0; i < filterItems.length; i++) {
    			logs.push(filterItems[i].textContent + "\r\n");              	
    		}
        	var file = new File(logs, "FilteredLogs.txt", {type: "text/plain;charset=utf-8"});
			saveAs(file);
    	},
    timeout: 5000 // sets timeout to 5 seconds
	});
  }); 
  
  // Because js/flot/jquery.flot.selection.js is not loaded in head i have to load it manually via Ajax
  $.ajax({
    	url: "js/flot/jquery.flot.selection.js",
    	dataType: "script",
    	error: function(){
        	alert("Error: File saving not sucessfull, perhaps js/flot/jquery.flot.selection.js missing!");
    	},
    	success: function(){          
           DialogLog.find('[data-ui-field="placeholder"]').bind("plotselected", function (event, ranges) {
        		plotflot = $.plot(plotarea, series,
                          $.extend(true, {}, options, {
                              xaxis: { min: ranges.xaxis.from, max: ranges.xaxis.to }
                          }));
    		});
        }
	}); 
  
  infolist = DialogLog.find("ul");
  //active selectable and tooltip functionality
  // TODO Does not work with Apple ipad scroll functionality
  //infolist.selectable();
  infolist.tooltip();
  
  infolist.on('click', 'li', function (e) {
    //var item = $(this);
    //alert(item.context.innerHTML.substring(25).replace("&gt;",">").replace("&lt;","<"));
	});
  
  // Close the original popup and open another one to show log context
  $$.popup.field('btn_info').on('click', function () {
    $$.ui.SwitchPopup($$.popup, DialogLog);
    $$.getLoglist(); // Get all current logbook items   
  });
    
  // Level slider release
  $$.field('onOff').on('slidestop', function () {
    $$.module.command('Control.' + ($(this).val() == 'on' || $(this).val() == '1' ? 'On' : 'Off'),'');
    $$.signalActity('description');
  }); 
  
  // Settings button click
  $$.field('settings').on('click', function () {
    // call the settings dialog.
  	$$.ui.EditModule($$.module);
    // ... and set the title property again   
	document.getElementById('module_title').innerHTML = $$.module.Domain.substring($$.module.Domain.lastIndexOf('.') + 1) + ' (' + $$.module.Address + ') - Settings';
  });
  
  // Duration value
  $$.field('duration').on('change', function() {
    $$.module.command('Rfm.Duration', $(this).val());
  });
  
  // option button click
  $$.field('options').on('click', function (){
    
    $$.loadDefaultBoards();
    $$.loadDefaultPins(0);
    $$.loadProperties();
        
    $$.popup.popup('open');  
    
    $$.popup.field('node_number').val(v_Node).trigger('change');
    $$.popup.field('cbBoardType').val(v_Board).selectmenu('refresh', true);
    $$.popup.field('cbPort').val(v_Port).selectmenu('refresh', true);
    $$.popup.field('iconOn').attr('src', v_IconOn);   
    $$.popup.field('iconOff').attr('src',v_IconOff);        		
  }); 
  
  $$.popup.field('btn_save').on('click', function() {
    $$.module.command('Rfm.Node', v_Node); 
    $$.module.command('Rfm.Boardtype', v_Board);
   	$$.module.command('Rfm.Port', v_Port);    
    $$.module.command('Rfm.IconOn',"'" + v_IconOn + "'"); 
    $$.module.command('Rfm.IconOff', "'" + v_IconOff + "'");
    
    // clean up a little biot for the next opening
    $$.clearFileInputs();
    $$.popup.field('module_iconslist', true).hide();
  });
  
  $$.popup.field('closeX').on('click', function(){ 
    $$.loadProperties(); 
    
    // clean up a little bit for the next opening
    $$.clearFileInputs();
    $$.popup.field('module_iconslist', true).hide();
  });
    
  $$.popup.field('cbBoardType').change(function () {
    v_Board = $(this).val();
    $$.loadDefaultPins($$.popup.field('cbBoardType').prop("selectedIndex"));
  });
  
  $$.popup.field('btn_cancel').on('click', function(){ 
    $$.loadProperties(); 
    
    // clean up a little bit for the next opening
    $$.clearFileInputs();
    $$.popup.field('module_iconslist', true).hide();
  }); 
  
  $$.popup.field('node_number').change(function () { v_Node = $(this).val();}); 
  
  $$.popup.field('cbPort').change(function () { v_Port = $(this).val(); });
  
  $$.popup.field('iconOn').on('click', function () {  
    isOnIcon = true;  
    $$.popup.field('module_iconslist', true).show(200);
  });
  
  $$.popup.field('iconOff').on('click', function () { 
    isOnIcon = false;	
    $$.popup.field('module_iconslist', true).show(200);
  }); 
  
  //
  // Attention: ONE event handler for all static or dynamically added icons 
  // of type 'img' to list 'module_iconslist'
  //
  $$.popup.field('module_iconslist').on('click', 'img', function () {  
    if (Boolean(isOnIcon) == true)
    { 
      v_IconOn = $(this).attr('src');
      $$.popup.field('iconOn',true).attr('src', v_IconOn).refresh;
    }
    else	
    {
      v_IconOff = $(this).attr('src');;          
      $$.popup.field('iconOff',true).attr('src', v_IconOff).refresh;
    }
    $$.popup.field('module_iconslist').hide(200); 
  });
  
  $$.popup.field('upload_file').on('change', function () {
    
    if ($(this).val() == "") 
      {
        $$.popup.field('fileinfo').html("").refresh;
        $$.popup.field('fileinfo').hide(200);
        $$.popup.field('upload_button', true).hide(200); 
      }    	
     else
       {
         var f = $(this).prop('files')[0];
         
         //TODO translate labels
         $$.popup.field('fileinfo').html($$.locales.GetWidgetLocaleString($$._widget,'rfm.arduino.upload_name','Name') + ": " + f.name + ", " + 
                                         $$.locales.GetWidgetLocaleString($$._widget,'rfm.arduino.upload_type','Type') + ": " + f.type + ", " + 
                                         $$.locales.GetWidgetLocaleString($$._widget,'rfm.arduino.upload_size','Size') + ": " + f.size + " Bytes").refresh;
         $$.popup.field('fileinfo').show(200);
       	 $$.popup.field('upload_button', true).show(200);        
       }
       
  });
  
  $$.popup.field('upload_button').on('click', function () {     
    var fs = $$.popup.field('upload_file');
    if (fs.prop('files').length > 0)
     {
       	var f = fs.prop('files')[0];
       	var filename = f.name.toLowerCase().replace(" ", "_");
     	var fReader = new FileReader();
		fReader.readAsDataURL(f);
		fReader.onloadend = function(event){
          	// event.target.result is the image data stream
          	// send a valid JSON format string
          	var data = event.target.result.replace("data:"+ f.type +";base64,", '');       	
          	var cmd = JSON.stringify({command: "Program.Upload", filename: filename, data: data});
          
  			$$.apiCall(cmd, $$.module.Domain, $$.module.Address, "", function (res) {
  				$$.updateIcons();
			});
          
     	}
        fReader.close;
       
       	
       	$$.clearFileInputs(); 	// clear all field inputs
        $$.updateIcons();		// update icon files selection container
  	}
  });
  
  $$.setDescription();
  $$.setStatusLine($$.module.prop('Status.Level'));
  
  $$.updateIcons();
}

$$.getTimeShift = function(date, zoomstate, isleft) {
  
  if (zoomstate == TimeDimension.Year)  	return (isleft == true ? moment(date).subtract(12,'months').toDate() : moment(date).add(12,'months').toDate());
  if (zoomstate == TimeDimension.Quarter)  	return (isleft == true ? moment(date).subtract(3,'months').toDate() : moment(date).add(3,'months').toDate());
  if (zoomstate == TimeDimension.Month) 	return (isleft == true ? moment(date).subtract(1,'months').toDate() : moment(date).add(1,'months').toDate());
  if (zoomstate == TimeDimension.Week)  	return (isleft == true ? moment(date).subtract(7,'days').toDate() : moment(date).add(7,'days').toDate());
  if (zoomstate == TimeDimension.Day)   	return (isleft == true ? moment(date).subtract(1,'days').toDate() : moment(date).add(1,'days').toDate());
  
  return (isleft == true ? moment(date).subtract(2,'hours').toDate() : moment(date).add(2,'hours').toDate());
}

//------------------------------------------------------------------------
// flot time format options of xaxis
//------------------------------------------------------------------------
//	%h: hours
//	%H: hours (left-padded with a zero)
//	%M: minutes (left-padded with a zero)
//	%S: seconds (left-padded with a zero)
//	%d: day of month (1-31), use %0d for zero-padding
//	%m: month (1-12), use %0m for zero-padding
//	%y: year (4 digits)
//	%b: month name (customizable)
//	%p: am/pm, additionally switches %h/%H to 12 hour instead of 24
//	%P: AM/PM (uppercase version of %p)
//
// for special formatting use options.xaxis.tickFormatter = function (val, axis) {return ....}

$$.plotGraph = function (area) {
  
  switch (area) {
    
    case TimeDimension.Now:
      	options.xaxis.min = minDate;
		options.xaxis.max = maxDate;
      	break;
      
    case TimeDimension.Earlier:      	
		options.xaxis.min = $$.getTimeShift(lastminDate, selectedZoom, true);
		options.xaxis.max = $$.getTimeShift(lastmaxDate, selectedZoom, true);     
      	break;
      
    case TimeDimension.Later:
      	options.xaxis.min = $$.getTimeShift(lastminDate, selectedZoom, false);
		options.xaxis.max = $$.getTimeShift(lastmaxDate, selectedZoom, false);
        break;
      
    case TimeDimension.Year:
      	options.xaxis.tickFormatter = "%b-%y";
        options.xaxis.timeformat = "%b-%y";
  		options.xaxis.minTickSize = [3, "month"];
  		options.xaxis.min =  moment().startOf('year').toDate();
  		options.xaxis.max =  moment().endOf('year').toDate();
        selectedZoom= TimeDimension.Year;
        break;
      
    case TimeDimension.Quarter:
      	options.xaxis.tickFormatter = "%b-%y";
        options.xaxis.timeformat = "%b-%y";
      	options.xaxis.minTickSize = [1, "month"];
      	options.xaxis.min = moment().startOf('quarter').toDate();
      	options.xaxis.max = moment().endOf('quarter').toDate();
        selectedZoom=TimeDimension.Quarter;
        break;
      
    case TimeDimension.Month:
       options.xaxis.tickFormatter = function (val, axis) {
          var dt = new Date(val);
          return dayOfWeek[$$.locales.GetUserLanguage()][dt.getDay()] +", "+ dt.getDate() +"."+ dt.getMonth() +"."},  
		options.xaxis.minTickSize = [7, "day"];
		options.xaxis.min = moment().startOf('month').toDate();
		options.xaxis.max = moment().endOf('month').toDate();
        selectedZoom=TimeDimension.Month;          	
        break;
      
    case TimeDimension.Week:
      	options.xaxis.tickFormatter = function (val, axis) {
          var dt = new Date(val);
          return dayOfWeek[$$.locales.GetUserLanguage()][dt.getDay()] +", "+ dt.getDate() +"."+ dt.getMonth() +"."},  
      	options.xaxis.minTickSize = [1, "day"];
		options.xaxis.min = moment().startOf('week').toDate();
      	options.xaxis.max =  moment().endOf('week').toDate();
	    selectedZoom = TimeDimension.Week;
        break;
      
    case TimeDimension.Day:
      	options.xaxis.tickFormatter = "%H:%M";
      	options.xaxis.timeformat = "%H:%M";
      	options.xaxis.minTickSize = [1, "hour"];
		options.xaxis.min = moment().startOf('day').toDate();
		options.xaxis.max = moment().endOf('day').toDate();
		selectedZoom = TimeDimension.Day;
        break;
      
    case TimeDimension.Hour:
      	options.xaxis.tickFormatter = "%H:%M";
        options.xaxis.timeformat = "%H:%M";
      	options.xaxis.minTickSize = [1, "minute"];
		options.xaxis.min = moment().startOf('hour').toDate();
		options.xaxis.max = moment().endOf('hour').toDate();
      	options.xaxis.twelveHourClock =  false;
		selectedZoom = TimeDimension.Hour;
        break;
}  
    
  // common for all time areas
  plotflot= $.plot(plotarea, series, options);
  
  lastminDate = plotflot.getAxes().xaxis.min;
  lastmaxDate = plotflot.getAxes().xaxis.max;
}

$$.getLoglist = function() {
  
    //
    // Add all context of rfmswitch.log file filtered for this module
    //
    var ul = DialogLog.find("ul"); // or DialogLog.find('[data-ui-field="infolist"]');
    var lc = DialogLog.find('[data-ui-field="listcounter"]');
    
    ul.empty();
    $$.apiCall("Program.GetLogs", $$.module.Domain, $$.module.Address, "", function (results) {
      results.lines.forEach(function(item){       
        var sub = item.substring(0,timelen) + " | " + item.substring(textbegin);
        ul.append('<li title="' + item.replace(/\"/gi," ") +'">' + sub + '</li>');
     });
     ul.listview('refresh');
     lc.html('Count: ' + ul.children("li").length); 
      
     $$.plotlog();
    });
}
  
$$.clearFileInputs = function () {
	$$.popup.field('fileinfo').html("").refresh;
    $$.popup.field('fileinfo').hide();
    $$.popup.field('upload_file').val("");
  	$$.popup.field('upload_button', true).hide(200); 
  	$$.popup.field('icon_collapsible').collapsible( "collapse" );
}

$$.onRefresh = function () {
  // Refresh UI fields
  $$.field('name').html($$.module.Name);
  // Control popup
  $$.popup.field('group').html($$.module.Domain.substring($$.module.Domain.lastIndexOf('.') + 1) + 
                               ' (' + $$.module.Address + ') - ' + 
                               $$.locales.GetWidgetLocaleString($$._widget,'rfm.arduino.ifaceparams','Interface parameters'));  
  
  $$.popup.field('name').html($$.module.Name); 
  
  // update slider and combobox
  $$.field('onOff').val($$.module.prop('Status.Level').Value).slider('refresh');
  $$.field('duration').val($$.module.prop('Rfm.Duration').Value).selectmenu('refresh');
  $$.setBigIcon($$.module.prop('Status.Level').Value);
  // get icon images
  $$.ui.GetModuleIcon($$.module, function(imgPath){
    $$.field('icon_small').attr('src', imgPath); // widget dialog icon
    $$.popup.field('icon').attr('src', imgPath); // widget options dialog icon
    $$.widget.icon = imgPath; // widget symbol icon
  });  
}

$$.onUpdate = function(parameter, value) { 
  	switch(parameter)  {
      case 'Status.Level':
        var state = $$.module.prop('Status.Level');
        $$.field('onOff').val(state.Value).slider('refresh');
        $$.setBigIcon(state.Value);
        $$.setStatusLine($$.module.prop('Status.Level'));
        break;
      
      case 'Rfm.NetId':
      case 'Rfm.Node':
      case 'Rfm.Port':
    	$$.setDescription();    
		break;
      
      case 'Rfm.Duration':
  		$$.field('duration').val($$.module.prop('Rfm.Duration').Value).selectmenu('refresh');
        break;
        
      case 'Rfm.IconOn':
      case 'Rfm.IconOff':
        $$.setBigIcon($$.module.prop('Status.Level').Value);
        break;
        
      	default: ;
    }
}

$$.setDescription = function () {
	$$.field('description').html("Node:'" + ($$.module.prop('Rfm.Node') != null ? $$.module.prop('Rfm.Node').Value : '') + "', " + 
                                 "Port:'" + ($$.module.prop('Rfm.Port') != null ? $$.module.prop('Rfm.Port').Value : '') + "'");  
}

$$.setStatusLine = function (level) {
  //
  // update time and LED display
  //
  var active_text = $$.locales.GetWidgetLocaleString($$._widget,'rfm.arduino.active','ACTIVE');
  var off_text =    $$.locales.GetWidgetLocaleString($$._widget,'rfm.arduino.off','OFF');
  var displayTime = '';

  //
  // Get module level prop for status text
  //
  if (level != null) {
    var updatetime = level.UpdateTime;
    if (typeof updatetime != 'undefined') {
      updatetime = updatetime.replace(' ', 'T'); // fix for IE and FF
      var d = new Date(updatetime);
      displayTime = $$.util.FormatDate(d) + ' ' + $$.util.FormatDateTime(d);
    } 
  }
  var lupText = displayTime != '' ? displayTime : 'Not updated';
  var isOn = '0';
  if (level != null) isOn = level.Value;

  var stateimage = (isOn == '1' ? 
                    '<img width="16" height="16" src="images/common/led_green.png" style="vertical-align:middle" />' : 
                    '<img width="16" height="16" src="images/common/led_black.png" style="vertical-align:middle" />');
  $$.field('status').html('<span style="vertical-align:middle">' + lupText + '  -  ' + (isOn == '1' ? active_text : off_text) + '</span>&nbsp;' + stateimage);
}

$$.setBigIcon = function (isOn) {
	// update status image left from slider object
  	var ion = $$.module.prop('Rfm.IconOn');
  	var ioff = $$.module.prop('Rfm.IconOff');
  	      
    if ((ion != null) && (ion.Value != '') && (ioff != null) && (ioff.Value != ''))
    {
      $$.field('icon_big').attr('src', (isOn == '1' ? ion.Value : ioff.Value)); 
    }
    else
    { 
      $$.field('icon_big').attr('src', $$.widget.processImages[isOn]); 
    } 
}

$$.loadBoardlist = function () {
  //
  // call the rfm switch program and ask for defined boards
  // in case of enhancements goto there and add your defintion
  //
  $$.apiCall("Program.GetBoardPins", $$.module.Domain, $$.module.Address, "", function (result) { 
    boardlist = result;
  });
}

$$.loadDefaultBoards = function () {
	//
    // Fill board combobox with default values from boardlist
    //
    $$.popup.field('cbBoardType').empty();
  	for (var j in boardlist)
    	{   
          	var opt = '<option value="' + boardlist[j].name + '"' + (j == 0 ? ' selected>' : '>') + boardlist[j].name + '</option>';
      		$$.popup.field('cbBoardType').append(opt); 
    	}
    $$.popup.field('cbBoardType').val(boardlist[0].name).selectmenu('refresh', true);         
}

$$.loadDefaultPins = function (boardidx) {
  	//
    // Fill pin combobox with default values from boardlist
    //
    $$.popup.field('cbPort').empty();
    var bpins = boardlist[boardidx].pins;
    for (var p = 0; p < bpins.length; p++)
    {
      var op2 = '<option value="' + bpins[p] + '">' + bpins[p] + '</option>';
      $$.popup.field('cbPort').append(op2);
    }      
    $$.popup.field('cbPort').select('refresh'); 
}

$$.loadProperties = function () {
    v_Node = $$.module.prop('Rfm.Node') != null ? $$.module.prop('Rfm.Node').Value : 1;
    v_Node = $$.module.prop('Rfm.Node') != null ? $$.module.prop('Rfm.Node').Value : 1;
    v_Board = $$.module.prop('Rfm.Boardtype') != null ? $$.module.prop('Rfm.Boardtype').Value : '';
    v_Port = $$.module.prop('Rfm.Port') != null ? $$.module.prop('Rfm.Port').Value : '';
    v_IconOn = $$.module.prop('Rfm.IconOn') != null ? $$.module.prop('Rfm.IconOn').Value : '';
    v_IconOff = $$.module.prop('Rfm.IconOff') != null ? $$.module.prop('Rfm.IconOff').Value : '';
}

$$.updateIcons = function () {
	// where to look for icons, fill it then step by step
  	$$.fillIconList("pages/control/widgets/homegenie/generic/images/icons/,pages/control/widgets/rfm/images/");     
}

$$.fillIconList = function (paths) {  
  //
  // create Json string with following structure
  // {"command":"Program.GetIcons","files":["pages/control/widgets/homegenie/generic/images/icons/","pages/control/widgets/rfm/images/"]}
  //
  $$.popup.field('module_iconslist').onclick = null;
  $$.popup.field('module_iconslist').empty();
  
  var jsonString = JSON.stringify({files: paths.split(',')});
  // $$.ApiCall = function (command, domain, address, options, callback)
  $$.apiCall("Program.GetIcons", $$.module.Domain, $$.module.Address, jsonString, function (results) {
    for (var j in results.files)
    {      
      var opt = '<img style="cursor: pointer; margin-left: 4px" src="' + results.files[j] + '" width="48" height="48" />';
      $$.popup.field('module_iconslist').append(opt);     
    } 		
  });
}

$$.onStop = function() {
  //TODO: ...
}
