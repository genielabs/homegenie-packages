/*
 * Hg2inoSpi.h
 * HomeGenie to Arduino SPI communication library, meant to be used with
 * Eden Board v2 - http://www.homegenie.it/diy/eden.php
 *
 * Copyright (c) 2014 G-Labs http://generoso.info
 * Author : Generoso Martello
 * Create Time : Dec 2014
 * Change Log :
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */

#include "Hg2inoSpi.h"

String inData;
bool cmdAvailable = false;
char buf[128];

char spi_transfer(volatile char data)
{
  SPDR = data;                    // Start the transmission
  while (!(SPSR & (1<<SPIF)))     // Wait the end of the transmission
  {
  };
  return SPDR;                    // return the received byte
}
void receiveMessage()
{
  char recv = (char)SPDR;
  if (recv == '\n')
  {
    inData += '\0';
    inData.toCharArray(buf, inData.length());
    cmdAvailable = true;
    inData = "";  
  }
  else
  {
    inData += recv;
  }
}

void Hg2inoSpi::begin()
{
  DDRB |= 0x21;
  PORTB |= 0x21;
  // have to send on master in, *slave out*
  pinMode(MISO, OUTPUT);
  // turn on SPI in slave mode
  SPCR |= _BV(SPE);   

  PORTD |= (1 << PORTD2);
  attachInterrupt(0, receiveMessage, FALLING);  
}

bool Hg2inoSpi::commandAvailable()
{
	return cmdAvailable;  
}

const char* Hg2inoSpi::getCommand()
{
    cmdAvailable = false;
	return buf;  
}

void Hg2inoSpi::sendResponse(const char* message)
{
  pinMode(SPI_INTERRUPT, OUTPUT);
  digitalWrite (SPI_INTERRUPT, LOW);
  delay(500);
  digitalWrite (SPI_INTERRUPT, HIGH);
  spi_transfer('\0');
  int m = 0;
  while(message[m])
  {
    spi_transfer(message[m]);
    m++;
  }
  spi_transfer('\n');
  digitalWrite (SPI_INTERRUPT, LOW);
  pinMode(SPI_INTERRUPT, INPUT);  
}

Hg2inoSpi Hg2ino;