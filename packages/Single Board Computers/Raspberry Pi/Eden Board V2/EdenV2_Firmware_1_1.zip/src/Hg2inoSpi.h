/*
 * Hg2inoSpi.h
 * HomeGenie to Arduino SPI communication library, meant to be used with
 * Eden Board v2 - http://www.homegenie.it/diy/eden.php
 *
 * Copyright (c) 2014 G-Labs http://generoso.info
 * Author : Generoso Martello
 * Create Time : Dec 2014
 * Change Log :
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */

#include <SPI.h>

// HomeGenie to Arduino SPI communication interrupt
#define SPI_INTERRUPT 2

class Hg2inoSpi {
  public:
  void begin();
  void sendResponse(const char* message);
  const char* getCommand();
  bool commandAvailable();
};
extern Hg2inoSpi Hg2ino; // Hg2ino object
