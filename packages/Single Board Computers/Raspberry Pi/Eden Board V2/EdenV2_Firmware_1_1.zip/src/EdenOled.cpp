/*
 * EdenOled.cpp
 * Extra Lcd Fonts library and symbols meant to be used with Seeed OLED display and SeeedOLED.cpp
 * and Eden Board v2 - http://www.homegenie.it/diy/eden.php
 *
 * Copyright (c) 2014 G-Labs http://generoso.info
 * Author : Generoso Martello
 * Create Time : Dec 2014
 * Change Log :
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */

#include "EdenOled.h"
#include <avr/pgmspace.h>

int EdenOled::drawLcdChar(const unsigned char* fontData, int cursorX, int row)
{
  int fontWidth = (int)pgm_read_byte(&fontData[1]);
  int fontSize = (int)pgm_read_byte(&fontData[2]);
  for (int y = 0; y < (fontSize / fontWidth); y++)
  {
    SeeedOled.sendCommand((0xB0 + row+y));// Set page address
    SeeedOled.sendCommand((0x00 + (cursorX & 0x0F)));	//set column lower address
    SeeedOled.sendCommand((0x10 + ((cursorX>>4)&0x0F))); //set column higher address
    for(int i = 0; i < fontWidth; i++)
    {
      SeeedOled.sendData(pgm_read_byte(&fontData[(y*fontWidth) + i + 3]));
    }
  } 
  return fontWidth; 
}

void EdenOled::drawString(const char* text, int cursorX, int row, int fontType)
{
  unsigned char c = 0;
  int items_2l = sizeof(lcdfont_2l)/sizeof(lcdfont_2l[0]);
  int items_3l = sizeof(lcdfont_3l)/sizeof(lcdfont_3l[0]);
  while (text[c])
  {
    switch(fontType)
    {
      case FONT_2L:
        for (int fm = 0; fm < items_2l; fm++)
        {
          if (pgm_read_byte(&lcdfont_2l[fm][0]) == text[c]) 
          {
            cursorX += drawLcdChar(lcdfont_2l[fm], cursorX, row);
            break;
          }
        }
      	break;
      case FONT_3L:
        for (int fm = 0; fm < items_3l; fm++)
        {
          if (pgm_read_byte(&lcdfont_3l[fm][0]) == text[c]) 
          {
            cursorX += drawLcdChar(lcdfont_3l[fm], cursorX, row);
            break;
          }
        }
      	break;
      break;
    }
    c++;
  }
}

void EdenOled::showLogo()
{
  SeeedOled.drawBitmap(logoHomeGenie, 512);  
}

EdenOled EdenDisplay; // Instantiate object